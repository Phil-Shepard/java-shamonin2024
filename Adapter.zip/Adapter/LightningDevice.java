package Adapter;

// Адаптируемый класс
public class LightningDevice {
    public void chargeWithLightning() {
        System.out.println("Зарядка устройства с разъёмом Lightning.");
    }
}

