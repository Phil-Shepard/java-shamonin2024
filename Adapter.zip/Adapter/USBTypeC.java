package Adapter;

// Целевой интерфейс
public interface USBTypeC {
    void chargeWithUSBC();
}

