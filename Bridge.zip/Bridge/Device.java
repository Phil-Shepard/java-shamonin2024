package Bridge;

//Паттерн Bridge
//Реализация
interface Device {
    void powerOn();
    void powerOff();
    void setVolume(int volume);
}