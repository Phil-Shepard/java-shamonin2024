package AbstractFactory;

// Абстрактный продукт
public interface Engine {
    void start();
}