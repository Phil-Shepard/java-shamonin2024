package AbstractFactory;

//Паттерн Abstract Factory
// Абстрактная фабрика
public interface CarFactory {
    Engine createEngine();
}

