package Composite;

// Компонент
interface Graphic {
    void draw();
}


