package Composite;

// Лист
class Square implements Graphic {
    @Override
    public void draw() {
        System.out.println("Square");
    }
}
