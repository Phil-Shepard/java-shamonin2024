package FactoryMethod;

// Продукт
interface Animal {
    void speak();
}
