package FactoryMethod;

// Паттерн Fabric Method
abstract class AnimalFactory {
    public abstract Animal createAnimal(); // Фабричный метод
}
