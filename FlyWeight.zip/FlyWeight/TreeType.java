package FlyWeight;

public interface TreeType {
    void draw(int x, int y);
}
