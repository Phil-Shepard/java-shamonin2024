package Decorator;

// Компонент
interface Coffee {
    String getDescription();
    double cost();
}




